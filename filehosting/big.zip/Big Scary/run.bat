@echo off
echo Starting Frida injection for Meta Game...
echo.

frida -U -l frida-il2cpp-bridge.js -l big_scary_menu.ts "Bigscary"

echo.
echo Frida script execution completed.
echo.
pause
echo Closing...